# FuncaoPretendida

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funcao** | **string** | Função pretendida pelo candidato  O valor informado deve estar presente na tabela Funcoes | 
**meses_de_experiencia** | **int** | Meses de experiência do candidato atuando naquela função | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


