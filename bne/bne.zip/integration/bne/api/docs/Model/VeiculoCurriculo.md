# VeiculoCurriculo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tipo_veiculo** | **string** | Tipo do veículo.  Deve conter um dos valores presentes na tabela TiposVeiculos | 
**descricao_modelo** | **string** | Descrição do modelo do veículo | [optional] 
**ano** | **int** | Ano de fabricação do veículo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


