# InlineResponse2006Perguntas

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id_pergunta** | **int** | Identificador da pergunta. | [optional] 
**texto** | **string** | Texto da pergunta. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


