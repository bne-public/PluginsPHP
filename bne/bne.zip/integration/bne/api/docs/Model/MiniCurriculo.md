# MiniCurriculo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vip** | **bool** |  | [optional] 
**nome** | **string** |  | [optional] 
**sexo** | **string** |  | [optional] 
**estado_civil** | **string** |  | [optional] 
**idade** | **int** |  | [optional] 
**escolaridade** | **string** |  | [optional] 
**pretensao** | **double** |  | [optional] 
**bairro** | **string** |  | [optional] 
**cidade** | **string** |  | [optional] 
**estado** | **string** |  | [optional] 
**funcoes** | **string** |  | [optional] 
**experiencia** | **string** |  | [optional] 
**carteira** | **string** |  | [optional] 
**id_curriculo** | **int** |  | [optional] 
**data_hora_candidatura** | [**\DateTime**](\DateTime.md) | Data e hora da candidatura. Propriedade somente será preenchida quando retornado pelos endpoints de recuperação de candidatura | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


