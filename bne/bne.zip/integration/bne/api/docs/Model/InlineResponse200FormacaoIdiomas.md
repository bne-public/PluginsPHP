# InlineResponse200FormacaoIdiomas

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descricao_idioma** | **string** | Descrição do idioma.  Deve ser um dos valores indicados na tabela Idiomas | 
**nivel_idioma** | **string** | Nível do idioma | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


