# InlineResponse2005Perguntas

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resposta** | **string** | (Obrigatório) Resposta para questão que pode ser \&quot;Sim\&quot; ou \&quot;Não\&quot;. | [optional] 
**id_pergunta** | **int** | Identificador da pergunta. | [optional] 
**texto** | **string** | Texto da pergunta. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


