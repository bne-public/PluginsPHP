# EmpresaSelecionadora

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cnpj** | **double** |  | [optional] 
**razao_social** | **string** |  | [optional] 
**nome_fantasia** | **string** |  | [optional] 
**matriz** | **bool** |  | [optional] 
**site** | **string** |  | [optional] 
**ddd_telefone** | **int** |  | [optional] 
**num_telefone** | **int** |  | [optional] 
**endereco** | [**\Swagger\Client\Model\InlineResponse2004Endereco**](InlineResponse2004Endereco.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


