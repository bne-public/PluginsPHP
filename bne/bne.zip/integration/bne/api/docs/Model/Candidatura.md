# Candidatura

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**respostas** | [**\Swagger\Client\Model\V10VagasCandidataridVagaRespostas[]**](V10VagasCandidataridVagaRespostas.md) | Respostas fornecidas pelo candidato | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


