# InlineResponse200Formacao

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idiomas** | [**\Swagger\Client\Model\InlineResponse200FormacaoIdiomas[]**](InlineResponse200FormacaoIdiomas.md) |  | [optional] 
**cursos_formacao** | [**\Swagger\Client\Model\InlineResponse200FormacaoCursosFormacao[]**](InlineResponse200FormacaoCursosFormacao.md) | Lista com os cursos de formação do candidato.  Nesta lista deve conter os cursos de Ensino Médio, incluindo técnicos,  Graduções e Especializações | [optional] 
**cursos_complementares** | [**\Swagger\Client\Model\InlineResponse200FormacaoCursosComplementares[]**](InlineResponse200FormacaoCursosComplementares.md) | Lista com os cursos complementares | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


