# Formacao

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descricao_formacao** | **string** |  | [optional] 
**descricao_curso** | **string** |  | [optional] 
**nome_fonte** | **string** |  | [optional] 
**sigla_fonte** | **string** |  | [optional] 
**situacao_formacao** | **string** |  | [optional] 
**ano_conclusao** | **int** |  | [optional] 
**periodo** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


