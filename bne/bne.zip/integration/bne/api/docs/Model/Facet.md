# Facet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**valor** | **string** | Valor do campo solicitado | [optional] 
**quantidade** | **int** | Quantidade de vezes em que o Valor aparece para o campo solicitado | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


