# FacetField

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**field_name** | **string** | Campo solicitado para sumarização | [optional] 
**facets** | [**\Swagger\Client\Model\InlineResponse2006Facets[]**](InlineResponse2006Facets.md) | Lista de valores e quantidades de ocorrência | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


