# InlineResponse2004Endereco

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cep** | **double** |  | [optional] 
**logradouro** | **string** |  | [optional] 
**numero** | **string** |  | [optional] 
**bairro** | **string** |  | [optional] 
**cidade** | **string** |  | [optional] 
**uf** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


