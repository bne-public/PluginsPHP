# Selecionadora

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id_pessoa** | **int** |  | [optional] 
**cpf** | **double** |  | [optional] 
**nome** | **string** |  | [optional] 
**sexo** | **string** |  | [optional] 
**nascimento** | **string** |  | [optional] 
**ddd_celular** | **int** |  | [optional] 
**num_celular** | **int** |  | [optional] 
**ddd_telefone** | **int** |  | [optional] 
**num_telefone** | **int** |  | [optional] 
**email** | **string** |  | [optional] 
**empresas** | [**\Swagger\Client\Model\InlineResponse2004Empresas[]**](InlineResponse2004Empresas.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


