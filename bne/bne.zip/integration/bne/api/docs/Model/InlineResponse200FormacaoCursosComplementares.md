# InlineResponse200FormacaoCursosComplementares

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instituicao** | **string** | Nome da instituição | 
**nome_curso** | **string** | Nome do curso  Recomenda-se o envio de um dos valores presentes na tabela Cursos. | 
**cidade** | **string** | Nome da cidade onde foi cursado  Formato: \&quot;NomeCidade/SiglaEstado\&quot; (Ex.: São Paulo/SP) | [optional] 
**ano_conclusao** | **int** | Ano de conclusão do curso. Pode ser passado ou futuro. | [optional] 
**carga_horaria** | **int** | Carga horária do curso | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


