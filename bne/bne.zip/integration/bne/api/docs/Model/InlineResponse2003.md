# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_de_registros** | **int** |  | [optional] 
**registros_por_pagina** | **int** |  | [optional] 
**curriculos** | [**\Swagger\Client\Model\InlineResponse2003Curriculos[]**](InlineResponse2003Curriculos.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


