# InlineResponse2002ListExperienciaProfissional

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**funcao** | **string** |  | [optional] 
**razao_social** | **string** |  | [optional] 
**descricao_atividade** | **string** |  | [optional] 
**area_bne** | **string** |  | [optional] 
**data_admissao** | [**\DateTime**](\DateTime.md) |  | [optional] 
**data_demissao** | [**\DateTime**](\DateTime.md) |  | [optional] 
**vlr_salario** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


